package com.snhu.sslserver;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController
class ServerController{
	public static String determineHash(String name) throws NoSuchAlgorithmException { // create method for calculating hash values
		MessageDigest md = MessageDigest.getInstance("SHA-256"); //determine hash algorithm
		byte[] hash = md.digest(name.getBytes(StandardCharsets.UTF_8)); //set hash variable to byte data type converted from name characters
		BigInteger number = new BigInteger(1, hash);//determine integer value for hash creation
		StringBuilder hexString = new StringBuilder(number.toString(16)); //convert to string for string builder
		while (hexString.length()<32) { //insert hex values for entire string
			hexString.insert(0,  '0');
		}
		return hexString.toString(); //return converted string
	}
	@RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException{ //added exception if algorithm does not exist
    	String data = "Hello World Check Sum!";
        String hash = determineHash(data); //call method to convert to hash
        
        return "<p>data:"+ data +"</p>" + "<p>Name of Cipher Algorithm Used: SHA-256" + "</p>" + "Checksum Value: " + hash + "</p>"; //output encryption method and hash
    }
}